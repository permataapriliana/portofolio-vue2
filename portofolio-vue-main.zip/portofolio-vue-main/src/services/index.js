import datas from './data.json';

const data = [
  ...datas,
];

export default data;
