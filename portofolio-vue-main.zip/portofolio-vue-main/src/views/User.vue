<template>
  <div>
    <user-name></user-name>
  </div>
</template>

<script>
import UserName from '../components/UserName';

export default {
  name: 'User',
  components: {
    UserName,
  },
};
</script>
