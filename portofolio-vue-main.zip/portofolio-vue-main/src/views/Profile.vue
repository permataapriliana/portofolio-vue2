<template>
  <div>
    <!-- must be declared in parent when using nested route -->
    <router-view/>
  </div>
</template>

<style scoped>
div {
  background: skyblue;
}
</style>
